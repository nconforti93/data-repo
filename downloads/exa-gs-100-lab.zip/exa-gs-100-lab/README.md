# EXA-GS-100 lab bundle (v1.2.0)

Course files for *Up and running with Exasol* (EXA-GS-100).

- `zones/taxi_zone_lookup.csv` - the NYC taxi zone names used in lesson 3.
- `live/setup.sql` - creates the view TAXI.V_NYE_TRIPS for lesson 5.
- `live/dashboard/` - the New Year's Eve dashboard, deployed by `install.sh` to the kit's Dash Server.
