# EXA-GS-100 lab bundle

Course files for *Up and running with Exasol* (EXA-GS-100).

- `zones/taxi_zone_lookup.csv` - the NYC taxi zone names used in lesson 3.
- `live/setup.sql` - creates TAXI.LIVE_TRIPS and four views for lesson 5.
- `live/replay.py` - the New Year's Eve replay (uv script, no venv needed).
- `live/dashboard/` - the dashboard app deployed by `install.sh` to the kit's Dash Server.
