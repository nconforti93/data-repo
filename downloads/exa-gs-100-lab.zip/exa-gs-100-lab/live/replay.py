# /// script
# requires-python = ">=3.11"
# dependencies = ["pyexasol>=3.0.1,<5.0"]
# ///
"""Replay NYC taxi trips into TAXI.LIVE_TRIPS, one simulated minute per tick.

    uv run replay.py                                       # NYE 2025 18:00 - 02:00, one simulated minute per second
    uv run replay.py --speed 10                            # ten simulated minutes per second
    uv run replay.py --start "2026-01-01 00:00" --end "2026-01-01 06:00" --keep

Reads the connection details and password from `exakit info --json`, so no credentials live in this file.
Needs `uv` (shipped with the starter kit) - no venv, no pip install.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

import pyexasol

INSERT = """
INSERT INTO TAXI.LIVE_TRIPS (PICKUP_TIME, DROPOFF_TIME, PICKUP_ZONE_ID, DROPOFF_ZONE_ID, PAYMENT_TYPE,
                             FARE_AMOUNT, TIP_AMOUNT, TOTAL_AMOUNT, TRIP_DISTANCE)
SELECT PICKUP_TIME, DROPOFF_TIME, PICKUP_ZONE_ID, DROPOFF_ZONE_ID, PAYMENT_TYPE,
       CAST(FARE_AMOUNT AS DECIMAL(9,2)), CAST(TIP_AMOUNT AS DECIMAL(9,2)),
       CAST(TOTAL_AMOUNT AS DECIMAL(9,2)), CAST(TRIP_DISTANCE AS DECIMAL(9,2))
FROM TAXI.TRIPS
WHERE PICKUP_TIME >= CAST({window_start} AS TIMESTAMP)
  AND PICKUP_TIME <  CAST({window_end} AS TIMESTAMP)
"""


def connect() -> pyexasol.ExaConnection:
    """Open a connection using the kit's own details."""
    try:
        info = json.loads(subprocess.check_output(["exakit", "info", "--json"], text=True, timeout=10))
    except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
        sys.exit(f"Cannot read `exakit info --json`: {e}. Is the starter kit installed?")
    rt = info.get("runtime") or {}
    host, _, port = rt.get("dsn", "127.0.0.1:8563").rpartition(":")
    password_file = Path(rt.get("password_file", ""))
    if not password_file.is_file():
        sys.exit(f"Password file not found: {password_file}. Is Exasol Personal running? (exakit start)")
    try:
        return pyexasol.connect(
            dsn=f"{host}/nocertcheck:{port}", user=rt.get("user", "sys"),
            password=password_file.read_text(encoding="utf-8").strip(),
            autocommit=True, client_name="exa-gs-100-replay",
        )
    except pyexasol.ExaError as e:
        sys.exit(f"Cannot connect to Exasol: {str(e).strip().splitlines()[0]}")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0],
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--start", default="2025-12-31 18:00",
                    help="first simulated minute (YYYY-MM-DD HH:MM)")
    ap.add_argument("--end", default="2026-01-01 02:00",
                    help="stop before this minute (YYYY-MM-DD HH:MM)")
    ap.add_argument("--speed", type=float, default=1.0, help="simulated minutes per real second")
    ap.add_argument("--keep", action="store_true", help="keep existing rows in TAXI.LIVE_TRIPS")
    a = ap.parse_args()

    start, end = datetime.fromisoformat(a.start), datetime.fromisoformat(a.end)
    conn = connect()
    try:
        if not a.keep:
            conn.execute("TRUNCATE TABLE TAXI.LIVE_TRIPS")
        print(f"Replaying {start:%Y-%m-%d %H:%M} to {end:%Y-%m-%d %H:%M} into TAXI.LIVE_TRIPS "
              f"at {a.speed:g} simulated minute(s) per second. Ctrl+C stops.")

        total, tick, t, began = 0, 0, start, time.monotonic()
        try:
            while t < end:
                nxt = t + timedelta(minutes=1)
                rows = conn.execute(INSERT, {"window_start": f"{t:%Y-%m-%d %H:%M:%S}",
                                             "window_end": f"{nxt:%Y-%m-%d %H:%M:%S}"}).rowcount()
                total += rows
                print(f"\r{t:%Y-%m-%d %H:%M}  +{rows:>5,} trips   total {total:>8,}", end="", flush=True)
                t, tick = nxt, tick + 1
                time.sleep(max(0.0, began + tick / a.speed - time.monotonic()))
        except KeyboardInterrupt:
            print(f"\nStopped at {t:%Y-%m-%d %H:%M} after {total:,} trips.")
            return
        print(f"\nDone: {total:,} trips replayed.")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
