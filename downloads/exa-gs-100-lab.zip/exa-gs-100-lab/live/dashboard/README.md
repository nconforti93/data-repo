# New Year's Eve on New York's taxis — the lesson 5 dashboard

A tiny Dash app, hosted on Exasol's built-in Dash Server (`exakit marketplace dash-server`), that reads
four views in schema `TAXI` as the kit's read-only user `MCP_READONLY`:

| View | Powers |
|---|---|
| `V_LIVE_TOTALS` | KPI tiles (trips so far, revenue, card-tip %, replay clock) |
| `V_TRIPS_PER_MINUTE` | line chart |
| `V_ZONE_HEAT` | choropleth map (`taxi_zones.geojson`) |
| `V_TOP_ZONES` | top-10 table — the one lesson 03 rewrites |

No credentials live in any file; the Dash Server runtime supplies them through the `starter-kit` profile.

## Deploy it

1. Create the views: run [../setup.sql](../setup.sql) in your SQL tool of choice.
2. Start Dash Server: `exakit start dash-server`.
3. Deploy: `./install.sh`.
4. Open the URL the script prints (default `http://127.0.0.1:5100/apps/nye-taxis`).

Then start the replay from the `../` folder: `uv run ../replay.py`. The dashboard polls every 2 seconds, so
the map darkens and the KPIs tick as the replay fills `TAXI.LIVE_TRIPS`.

## Change a panel

Rewrite one of the views in your SQL tool (`CREATE OR REPLACE VIEW TAXI.V_TOP_ZONES AS …`). The dashboard's
next 2-second poll picks up the new shape. No redeploy.
