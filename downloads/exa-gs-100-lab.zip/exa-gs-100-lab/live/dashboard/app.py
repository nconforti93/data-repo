"""EXA-GS-100 lesson 5: a live New Year's Eve 2025 dashboard on New York's yellow taxis.

Every panel reads a view in schema TAXI as MCP_READONLY, through Dash Server's starter-kit profile. The
app refreshes every 2 seconds, so a learner changes what a panel shows by rewriting the view behind it
(for example CREATE OR REPLACE VIEW TAXI.V_TOP_ZONES AS ... with a WHERE clause for the last hour of 2025):
the next poll picks up the new shape - no redeploy and no credentials in any file.
"""
import importlib.util
import json
from pathlib import Path

import plotly.graph_objects as go
from dash import Dash, Input, Output, dcc, html

HERE = Path(__file__).parent
_spec = importlib.util.spec_from_file_location("dse", HERE / "dash_server_exasol.py")
dse = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(dse)

TITLE = "New Year's Eve on New York's taxis"
SUBTITLE = "Replay of 18:00 - 02:00 on NYE 2025 - every panel is one view in TAXI"
REFRESH_MS = 2000
NAVY, BG = "#1f3047", "#f3f4f6"
CARD = {"background": "white", "borderRadius": "10px", "padding": "14px 18px",
        "boxShadow": "0 1px 3px rgba(0,0,0,.08)"}

ZONES_GEOJSON = json.loads((HERE / "taxi_zones.geojson").read_text(encoding="utf-8"))
for _feature in ZONES_GEOJSON["features"]:
    _feature["id"] = str(_feature["id"])


def _fmt_int(n, prefix="", suffix=""):
    return "—" if n in (None, "") else f"{prefix}{int(n):,}{suffix}"


def _fmt_pct(n):
    return "—" if n in (None, "") else f"{float(n):.1f}%"


def _kpi(label, value):
    return html.Div(
        [html.Div(label, style={"fontSize": "12px", "color": "#666", "textTransform": "uppercase",
                                "letterSpacing": "0.04em"}),
         html.Div(value, style={"fontSize": "28px", "fontWeight": 700, "color": NAVY, "marginTop": "4px"})],
        style={**CARD, "flex": 1, "minWidth": "180px"},
    )


def _map_figure(rows):
    if dse.has_error(rows) or not rows:
        return go.Figure(layout={"height": 520, "margin": {"l": 0, "r": 0, "t": 0, "b": 0},
                                 "map": {"style": "carto-positron",
                                         "center": {"lat": 40.73, "lon": -73.93}, "zoom": 9.2}})
    fig = go.Figure(go.Choroplethmap(
        geojson=ZONES_GEOJSON,
        locations=[str(r["ZONE_ID"]) for r in rows],
        z=[r["PICKUPS"] for r in rows],
        colorscale="YlOrRd",
        marker={"opacity": 0.65, "line": {"width": 0.3, "color": "white"}},
        hovertemplate="Zone %{location}<br>%{z:,} pickups<extra></extra>",
        colorbar={"title": {"text": "Pickups"}, "thickness": 12, "len": 0.55, "x": 0.99,
                  "xanchor": "right", "bgcolor": "rgba(255,255,255,.85)"},
    ))
    fig.update_layout(
        map={"style": "carto-positron", "center": {"lat": 40.73, "lon": -73.93}, "zoom": 9.2},
        height=520, margin={"l": 0, "r": 0, "t": 0, "b": 0}, uirevision="keep",
    )
    return fig


def _line_figure(rows):
    fig = go.Figure(layout={"height": 240, "margin": {"l": 50, "r": 10, "t": 10, "b": 30},
                            "plot_bgcolor": "white", "uirevision": "keep",
                            "xaxis": {"gridcolor": "#f1f5f9"},
                            "yaxis": {"title": "Trips", "gridcolor": "#e5e7eb"}})
    if dse.has_error(rows) or not rows:
        return fig
    fig.add_trace(go.Scatter(
        x=[r["PICKUP_MINUTE"] for r in rows],
        y=[r["TRIPS"] for r in rows],
        mode="lines", line={"color": "#2563eb", "width": 2},
        hovertemplate="%{x|%H:%M}<br>%{y:,} trips<extra></extra>",
    ))
    return fig


def _table(rows):
    if dse.has_error(rows):
        return dse.render_error_panel(rows[0]["_error"])
    if not rows:
        return html.Div("Waiting for trips…", style={"color": "#94a3b8", "padding": "12px 0"})
    header = html.Thead(html.Tr([html.Th(c, style={"textAlign": "left", "padding": "6px 10px",
                                                   "borderBottom": "1px solid #e5e7eb",
                                                   "fontSize": "12px", "color": "#64748b"})
                                 for c in rows[0].keys()]))
    body = html.Tbody([
        html.Tr([html.Td(f"{v:,}" if isinstance(v, (int, float)) else str(v),
                         style={"padding": "6px 10px", "borderBottom": "1px solid #f1f5f9",
                                "fontSize": "13px"}) for v in row.values()])
        for row in rows
    ])
    return html.Table([header, body], style={"borderCollapse": "collapse", "width": "100%"})


def create_dash_app(server, url_base_pathname, metadata):
    app = Dash(__name__, server=server, routes_pathname_prefix="/",
               requests_pathname_prefix=url_base_pathname.rstrip("/") + "/", title=TITLE)

    app.layout = html.Div(
        style={"fontFamily": "system-ui, sans-serif", "background": BG, "padding": "18px",
               "minHeight": "100vh"},
        children=[
            dcc.Interval(id="tick", interval=REFRESH_MS),
            html.Div(style={**CARD, "background": NAVY, "color": "white", "marginBottom": "14px"}, children=[
                html.Div(TITLE, style={"fontSize": "20px", "fontWeight": 700}),
                html.Div(SUBTITLE, style={"fontSize": "13px", "color": "#cbd5e1", "marginTop": "2px"}),
            ]),
            html.Div(id="kpis", style={"display": "flex", "gap": "14px", "flexWrap": "wrap",
                                       "marginBottom": "14px"}),
            html.Div(style={"display": "grid", "gridTemplateColumns": "minmax(0, 1.4fr) minmax(0, 1fr)",
                            "gap": "14px"}, children=[
                html.Div(style=CARD, children=[
                    html.Div("Pickups per taxi zone", style={"fontWeight": 600, "marginBottom": "8px"}),
                    dcc.Graph(id="zone-map", config={"scrollZoom": True, "displayModeBar": False}),
                ]),
                html.Div(style={"display": "flex", "flexDirection": "column", "gap": "14px",
                                "minWidth": 0}, children=[
                    html.Div(style=CARD, children=[
                        html.Div("Trips per minute", style={"fontWeight": 600, "marginBottom": "8px"}),
                        dcc.Graph(id="trips-line", config={"displayModeBar": False}),
                    ]),
                    html.Div(style=CARD, children=[
                        html.Div("Top 10 pickup zones", style={"fontWeight": 600, "marginBottom": "8px"}),
                        html.Div(id="top-table"),
                    ]),
                ]),
            ]),
        ],
    )

    @app.callback(
        Output("kpis", "children"), Output("zone-map", "figure"),
        Output("trips-line", "figure"), Output("top-table", "children"),
        Input("tick", "n_intervals"),
    )
    def refresh(_):
        totals = dse.load_row(server, metadata, __file__, "queries/live_totals.sql") or {}
        zones = dse.load_rows(server, metadata, __file__, "queries/zone_heat.sql")
        per_minute = dse.load_rows(server, metadata, __file__, "queries/trips_per_minute.sql")
        top = dse.load_rows(server, metadata, __file__, "queries/top_zones.sql")

        if totals.get("_error"):
            tiles = [dse.render_error_panel(totals["_error"])]
        else:
            tiles = [
                _kpi("Trips so far", _fmt_int(totals.get("TRIPS_SO_FAR"))),
                _kpi("Revenue", _fmt_int(totals.get("REVENUE_USD"), prefix="$")),
                _kpi("Card tip %", _fmt_pct(totals.get("CARD_TIP_PCT"))),
                _kpi("Replay clock", totals.get("CLOCK") or "—"),
            ]
        return tiles, _map_figure(zones), _line_figure(per_minute), _table(top)

    return app
