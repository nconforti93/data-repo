-- EXA-GS-100 lesson 5 setup: one table and four views for the live New Year's Eve dashboard.
--
-- The learner's replay (replay.py) writes one minute of trips per second into TAXI.LIVE_TRIPS. The dashboard,
-- hosted on the kit's dash-server add-on, queries the views - never the base tables - so a learner can change
-- what a panel shows by rewriting one view and refreshing the page. No redeploy, no file-editing inside the
-- server.
--
-- Views are owned by SYS and read for the dashboard's user, MCP_READONLY (created by the starter kit at
-- install time, which is why no explicit CREATE USER is needed here). An Exasol view runs as its definer,
-- so granting SELECT on the view is enough - MCP_READONLY never needs direct rights on the base tables,
-- which keeps the read-only story clean.

CREATE OR REPLACE TABLE TAXI.LIVE_TRIPS (
    PICKUP_TIME      TIMESTAMP,
    DROPOFF_TIME     TIMESTAMP,
    PICKUP_ZONE_ID   DECIMAL(3,0),
    DROPOFF_ZONE_ID  DECIMAL(3,0),
    PAYMENT_TYPE     DECIMAL(2,0),
    FARE_AMOUNT      DECIMAL(9,2),
    TIP_AMOUNT       DECIMAL(9,2),
    TOTAL_AMOUNT     DECIMAL(9,2),
    TRIP_DISTANCE    DECIMAL(9,2)
);

-- KPI tiles: trips so far, revenue, average tip on card payments, the replay's clock.
CREATE OR REPLACE VIEW TAXI.V_LIVE_TOTALS AS
SELECT COUNT(*)                                           AS TRIPS_SO_FAR,
       ROUND(SUM(TOTAL_AMOUNT), 0)                        AS REVENUE_USD,
       ROUND(100 * SUM(CASE WHEN PAYMENT_TYPE = 1 AND FARE_AMOUNT > 0 THEN TIP_AMOUNT END)
                 / NULLIF(SUM(CASE WHEN PAYMENT_TYPE = 1 AND FARE_AMOUNT > 0 THEN FARE_AMOUNT END), 0), 1)
                                                          AS CARD_TIP_PCT,
       TO_CHAR(MAX(PICKUP_TIME), 'YYYY-MM-DD HH24:MI')    AS CLOCK
FROM TAXI.LIVE_TRIPS;

-- Trips per minute, as the night unfolds.
CREATE OR REPLACE VIEW TAXI.V_TRIPS_PER_MINUTE AS
SELECT TRUNC(PICKUP_TIME, 'MI')  AS PICKUP_MINUTE,
       COUNT(*)                  AS TRIPS
FROM TAXI.LIVE_TRIPS
GROUP BY TRUNC(PICKUP_TIME, 'MI');

-- Pickups per taxi zone, for the choropleth map.
CREATE OR REPLACE VIEW TAXI.V_ZONE_HEAT AS
SELECT PICKUP_ZONE_ID  AS ZONE_ID,
       COUNT(*)        AS PICKUPS
FROM TAXI.LIVE_TRIPS
GROUP BY PICKUP_ZONE_ID;

-- Top 10 pickup zones. The lesson's "change a view" lab rewrites this one to add a WHERE clause
-- that only counts the last hour of 2025.
CREATE OR REPLACE VIEW TAXI.V_TOP_ZONES AS
SELECT z.ZONE_NAME,
       z.BOROUGH,
       COUNT(*) AS PICKUPS
FROM TAXI.LIVE_TRIPS t
JOIN TAXI.ZONES z ON z.LOCATION_ID = t.PICKUP_ZONE_ID
GROUP BY z.ZONE_NAME, z.BOROUGH
ORDER BY PICKUPS DESC
LIMIT 10;

GRANT SELECT ON TAXI.V_LIVE_TOTALS       TO MCP_READONLY;
GRANT SELECT ON TAXI.V_TRIPS_PER_MINUTE  TO MCP_READONLY;
GRANT SELECT ON TAXI.V_ZONE_HEAT         TO MCP_READONLY;
GRANT SELECT ON TAXI.V_TOP_ZONES         TO MCP_READONLY;
