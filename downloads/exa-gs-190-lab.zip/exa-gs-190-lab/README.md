# EXA-GS-190 lab bundle (v1.3.1)

Course files for *Capstone: build your own Exasol dashboard* (EXA-GS-190).

- `self-check.sql` - lesson 2: installs the script CAPSTONE.SELF_CHECK, which checks your four views
  (`exasol connect -f ~/exa-gs-190-lab/self-check.sql`, then `EXECUTE SCRIPT CAPSTONE.SELF_CHECK();`).
- `dashboard/` - lesson 3: your dashboard, one panel per view; each panel is a SQL file in `dashboard/queries/`.
  `dashboard/install.sh` deploys it to the kit's Dash Server as the app `capstone`.
