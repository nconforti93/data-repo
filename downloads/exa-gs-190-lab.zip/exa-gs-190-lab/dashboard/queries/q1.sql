-- title: Top 5 pickup zones, New Year's Eve 22:00-02:00
-- chart: table
-- Panel 1 reads your view CAPSTONE.Q1_TOP_ZONES. Charts: table, bar, number, map - see README.md.
SELECT * FROM CAPSTONE.Q1_TOP_ZONES
