-- title: Card tip % per borough, New Year's Eve 22:00-02:00
-- chart: table
-- Panel 2 reads your view CAPSTONE.Q2_CARD_TIPS. Charts: table, bar, number, map - see README.md.
SELECT * FROM CAPSTONE.Q2_CARD_TIPS
