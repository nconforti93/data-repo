-- title: Best zone per borough, forecast for Saturday 22:00
-- chart: table
-- Panel 3 reads your view CAPSTONE.Q3_BEST_ZONES. Charts: table, bar, number, map - see README.md.
SELECT * FROM CAPSTONE.Q3_BEST_ZONES
