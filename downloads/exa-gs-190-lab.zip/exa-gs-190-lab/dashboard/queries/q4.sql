-- title: Trips that started near an airport, New Year's Eve 22:00-02:00
-- chart: table
-- Panel 4 reads your view CAPSTONE.Q4_AIRPORT_SHARE. Charts: table, bar, number, map - see README.md.
SELECT * FROM CAPSTONE.Q4_AIRPORT_SHARE
