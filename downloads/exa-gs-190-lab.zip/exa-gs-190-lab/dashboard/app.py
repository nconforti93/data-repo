"""EXA-GS-190 capstone: your own New Year's Eve dashboard, four panels on your four views in schema CAPSTONE.

Each panel is one SQL file in queries/ (q1.sql ... q4.sql; add q5.sql for a fifth panel). Its first lines say what
the panel shows:

    -- title: Top 5 pickup zones, New Year's Eve 22:00-02:00
    -- chart: bar
    SELECT ZONE_NAME, PICKUPS FROM CAPSTONE.Q1_TOP_ZONES ORDER BY PICKUP_RANK

Charts: table (every column), bar (first column the labels, second the values, in the order of the query),
number (one tile per column of the first row) and map (first column a taxi zone id, second the value).
Change a file, run ./install.sh again, reload the page. The queries run as the kit's read-only user through Dash
Server's starter-kit profile - no credentials in any file - when the page loads and every 10 seconds, so a view you
rewrite shows up without a redeploy.
"""
import hashlib
import importlib.util
import json
import re
from pathlib import Path

import plotly.graph_objects as go
from dash import Dash, Input, Output, State, dcc, html, no_update

HERE = Path(__file__).parent
_spec = importlib.util.spec_from_file_location("dse", HERE / "dash_server_exasol.py")
dse = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(dse)

TITLE = "My New Year's Eve dashboard"
SUBTITLE = "Four questions for a taxi fleet, answered by my views in schema CAPSTONE"
# One panel per SQL file, in the order of the file names: queries/q1.sql, queries/q2.sql, queries/q3.sql,
# queries/q4.sql - and any file you add, such as queries/q5.sql.
PANELS = sorted(p.relative_to(HERE).as_posix() for p in (HERE / "queries").glob("*.sql"))
CHARTS = ("table", "bar", "number", "map")
REFRESH_MS = 10000
MAX_TABLE_ROWS = 50

INK, MUTED, LINE, NAVY, ACCENT, BG = "#0f172a", "#64748b", "#e2e8f0", "#1f3047", "#2563eb", "#f3f4f6"
CARD = {"background": "white", "borderRadius": "10px", "padding": "12px 16px",
        "boxShadow": "0 1px 3px rgba(0,0,0,.08)", "minWidth": 0}
# Light to dark blue; even the lowest value is a clear blue against the gray zones that are not in the result.
MAP_SCALE = [[0.0, "#93c5fd"], [0.4, "#3b82f6"], [0.75, "#1d4ed8"], [1.0, "#172554"]]

# The taxi zone shapes for the map panel (several shapes can share a zone id).
ZONES_GEOJSON = json.loads((HERE / "taxi_zones.geojson").read_text(encoding="utf-8"))
SHAPE_ZONE, SHAPE_NAME = [], []
for i, feature in enumerate(ZONES_GEOJSON["features"]):
    props = feature.get("properties") or {}
    feature["id"] = str(i)
    SHAPE_ZONE.append(int(props.get("LocationID") or -1))
    SHAPE_NAME.append(f"{props.get('zone', '?')} ({props.get('borough', '?')})")
SHAPE_IDS = [str(i) for i in range(len(SHAPE_ZONE))]


def panel_spec(path):
    """Title and chart type from the -- title: and -- chart: lines of a panel's SQL file."""
    text = (HERE / path).read_text(encoding="utf-8")
    title = re.search(r"^--\s*title:\s*(.+?)\s*$", text, re.M | re.I)
    chart = re.search(r"^--\s*chart:\s*(\w+)\s*$", text, re.M | re.I)
    return {"path": path, "title": title.group(1) if title else path,
            "chart": chart.group(1).lower() if chart else "table"}


def num(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def fmt(value):
    """Whole numbers with thousands separators, other numbers with up to 2 decimals, text as it is."""
    x = num(value)
    if x is None:
        return "" if value is None else str(value)
    if x == int(x) and "." not in str(value).rstrip("0").rstrip("."):
        return f"{int(x):,}"
    return f"{x:,.2f}".rstrip("0").rstrip(".")


def message(text, warn=True):
    style = {"padding": "10px", "borderRadius": "8px", "fontSize": "13px", "whiteSpace": "pre-wrap",
             "wordBreak": "break-word", "color": INK}
    if warn:
        style.update({"background": "#fff7ed", "border": "1px solid #fdba74"})
    return html.Div(text, style=style)


def render_table(rows):
    columns = list(rows[0].keys())
    numeric = {c: all(num(r.get(c)) is not None for r in rows if r.get(c) is not None) for c in columns}
    th = {"padding": "4px 8px", "fontSize": "11px", "color": MUTED, "fontWeight": 500,
          "borderBottom": f"1px solid {LINE}"}
    td = {"padding": "4px 8px", "fontSize": "13px", "color": INK, "borderBottom": "1px solid #f1f5f9",
          "fontVariantNumeric": "tabular-nums"}
    align = {c: "right" if numeric[c] else "left" for c in columns}
    body = [html.Tr([html.Td(fmt(r.get(c)), style={**td, "textAlign": align[c]}) for c in columns])
            for r in rows[:MAX_TABLE_ROWS]]
    head = html.Thead(html.Tr([html.Th(c, style={**th, "textAlign": align[c]}) for c in columns]))
    return html.Table([head, html.Tbody(body)], style={"borderCollapse": "collapse", "width": "100%"})


def render_bar(rows):
    columns = list(rows[0].keys())
    if len(columns) < 2:
        return message("A bar chart needs two columns: the labels first, then the values.")
    labels = [str(r[columns[0]]) for r in rows]
    values = [num(r[columns[1]]) or 0 for r in rows]
    fig = go.Figure(go.Bar(x=values, y=labels, orientation="h", marker_color=ACCENT,
                           text=[fmt(r[columns[1]]) for r in rows], textposition="auto",
                           hovertemplate="%{y}: %{text}<extra></extra>"))
    fig.update_layout(height=max(160, 46 * len(rows) + 50), margin={"l": 8, "r": 8, "t": 4, "b": 30},
                      plot_bgcolor="white", xaxis={"title": columns[1], "gridcolor": LINE},
                      yaxis={"autorange": "reversed", "automargin": True})
    return dcc.Graph(figure=fig, config={"displayModeBar": False})


def render_number(rows):
    row = rows[0]
    tiles = [html.Div([html.Div(c, style={"fontSize": "11px", "color": MUTED, "letterSpacing": "0.04em"}),
                       html.Div(fmt(v), style={"fontSize": "26px", "fontWeight": 700, "color": NAVY,
                                               "fontVariantNumeric": "tabular-nums"})],
                      style={"flex": "1 1 120px", "padding": "6px 4px"})
             for c, v in row.items()]
    return html.Div(tiles, style={"display": "flex", "flexWrap": "wrap", "gap": "10px"})


def render_map(rows):
    columns = list(rows[0].keys())
    if len(columns) < 2:
        return message("A map needs two columns: a taxi zone id (ZONE_ID) first, then the value.")
    values, extra = {}, {}
    for r in rows:
        zone = num(r[columns[0]])
        if zone is not None:
            values[int(zone)] = num(r[columns[1]])
            extra[int(zone)] = " · ".join(fmt(r[c]) for c in columns[2:])
    on_map = [i for i, zone in enumerate(SHAPE_ZONE) if zone in values]
    # Only the shapes of the zones in the result go to the browser - not the 2 MB of all of them.
    shapes = {"type": "FeatureCollection", "features": [ZONES_GEOJSON["features"][i] for i in on_map]}
    fig = go.Figure(go.Choroplethmap(
        geojson=shapes, locations=[SHAPE_IDS[i] for i in on_map],
        z=[values[SHAPE_ZONE[i]] or 0 for i in on_map], colorscale=MAP_SCALE,
        text=[SHAPE_NAME[i] for i in on_map], customdata=[extra[SHAPE_ZONE[i]] for i in on_map],
        marker={"opacity": 0.9, "line": {"width": 0.6, "color": "white"}},
        hovertemplate="%{text}<br>" + columns[1] + ": %{z:,}<br>%{customdata}<extra></extra>",
        colorbar={"title": {"text": columns[1], "font": {"size": 10}}, "thickness": 10, "len": 0.5,
                  "x": 0.99, "xanchor": "right", "y": 0.98, "yanchor": "top", "tickfont": {"size": 10},
                  "bgcolor": "rgba(255,255,255,.85)"}))
    fig.update_layout(height=380, margin={"l": 0, "r": 0, "t": 0, "b": 0},
                      map={"style": "carto-positron", "center": {"lat": 40.70, "lon": -73.93}, "zoom": 9.2})
    return dcc.Graph(figure=fig, config={"scrollZoom": False, "displayModeBar": False})


RENDER = {"table": render_table, "bar": render_bar, "number": render_number, "map": render_map}


def render(spec, rows):
    if spec["chart"] not in CHARTS:
        return message(f"Unknown chart '{spec['chart']}' in {spec['path']} - use one of: {', '.join(CHARTS)}.")
    if dse.has_error(rows):
        return message("Exasol query failed:\n" + str(rows[0].get("_error") or "unknown error"))
    if not rows:
        return message("The query returned no rows.", warn=False)
    return RENDER[spec["chart"]](rows)


def release_session(server):
    """Close this request's database session now (Dash Server 0.2.1 keeps one per request thread)."""
    try:
        server.extensions["exasol_dashboard_service"].connection_manager.close_all_for_thread()
    except Exception:  # noqa: BLE001 - never let the clean-up break a panel
        pass


def create_dash_app(server, url_base_pathname, metadata):
    app = Dash(__name__, server=server, routes_pathname_prefix="/",
               requests_pathname_prefix=url_base_pathname.rstrip("/") + "/", title=TITLE)
    specs = [panel_spec(p) for p in PANELS]

    def card(i, spec):
        return html.Div(style={**CARD, "flex": "1 1 440px"}, children=[
            html.Div(spec["title"], style={"fontWeight": 600, "fontSize": "15px", "color": INK}),
            html.Div(f"{spec['path']} · chart: {spec['chart']}",
                     style={"fontSize": "11px", "color": MUTED, "margin": "2px 0 8px"}),
            html.Div(id=f"panel-{i}"),
        ])

    app.layout = html.Div(
        style={"fontFamily": "system-ui, -apple-system, Segoe UI, sans-serif", "background": BG,
               "padding": "12px 14px", "boxSizing": "border-box", "minHeight": "calc(100vh - 34px)"},
        children=[
            dcc.Interval(id="refresh", interval=REFRESH_MS),
            dcc.Store(id="results"),
            html.Div(style={**CARD, "background": NAVY, "color": "white", "marginBottom": "10px"}, children=[
                html.Div(TITLE, style={"fontSize": "18px", "fontWeight": 700}),
                html.Div(SUBTITLE, style={"fontSize": "12.5px", "color": "#cbd5e1"}),
            ]),
            html.Div([card(i, s) for i, s in enumerate(specs)],
                     style={"display": "flex", "flexWrap": "wrap", "gap": "10px"}),
        ],
    )

    # Every refresh runs all queries; a panel is drawn again only when its result changed (no flicker, less traffic).
    @app.callback([Output(f"panel-{i}", "children") for i in range(len(specs))] + [Output("results", "data")],
                  Input("refresh", "n_intervals"), State("results", "data"))
    def update(_n, before):
        before = before or {}
        out, now = [], {}
        for spec in specs:
            rows = dse.load_rows(server, metadata, __file__, spec["path"])
            now[spec["path"]] = hashlib.sha256(json.dumps(rows, default=str, sort_keys=True).encode()).hexdigest()
            out.append(no_update if before.get(spec["path"]) == now[spec["path"]] else render(spec, rows))
        release_session(server)
        return out + [now]

    return app
