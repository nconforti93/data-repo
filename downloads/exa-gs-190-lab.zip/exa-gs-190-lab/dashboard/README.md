# Your capstone dashboard

A small Dash app, hosted on the starter kit's Dash Server, with four panels – one per view in schema `CAPSTONE`.
Each panel is one SQL file in `queries/`; you decide what it selects and how it is drawn. The app runs the four
queries as the kit's read-only user `MCP_READONLY` when the page loads and every 10 seconds.

| File | What it does |
|---|---|
| `queries/q1.sql` … `queries/q4.sql` | one panel each: a `-- title:` line, a `-- chart:` line and one `SELECT`; every `.sql` file you add there (`q5.sql`) is one more panel, in the order of the file names |
| `app.py` | reads the four files and draws the panels |
| `taxi_zones.geojson` | the taxi zone shapes for the map chart (NYC Open Data) |
| `dash-app.json`, `requirements.txt` | app name, route, the `starter-kit` database profile, Python packages |
| `install.sh`, `install.py` | upload the files to Dash Server and deploy the app |

No credentials live in any file: Dash Server supplies them through its `starter-kit` profile.

## Charts

| `-- chart:` | Columns it needs | Draws |
|---|---|---|
| `table` | any | every column, up to 50 rows |
| `bar` | labels, then values | one horizontal bar per row, in the order of your `ORDER BY` |
| `number` | any, one row | one big number per column of the first row |
| `map` | a taxi zone id (`ZONE_ID`), then a value; more columns show on hover | the zones in your result, colored by the value |

## Deploy it

1. Your four views exist (`EXECUTE SCRIPT CAPSTONE.SELF_CHECK();` says OK four times). Dash Server test-runs each
   panel's query before it deploys; a missing view stops the deploy.
2. Check that Dash Server runs: `exakit status` (else `exakit start dash-server`).
3. Deploy: `./install.sh` in this folder (run it again after you change a file here).
4. Open the address the script prints (default `http://127.0.0.1:5100/apps/capstone`).

The app is called `capstone`, so the New Year's Eve dashboard of the first course (`nye-taxis`) stays as it is.
