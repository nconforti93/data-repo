-- EXA-GS-190 self-check for your four capstone views.
--
-- Install it once (it prints nothing):   exasol connect -f ~/exa-gs-190-lab/self-check.sql
-- Then run it as often as you like, at the SQL prompt:   EXECUTE SCRIPT CAPSTONE.SELF_CHECK();
--
-- One row per question: OK, wrong values, view/column missing or view fails, with a hint.
-- The answers are not in this file. For each view, the script rounds your results, writes them as one line of text
-- in a fixed order and compares a fingerprint of that text (SHA-256) with the fingerprint of the expected result.
-- The order of your rows and columns does not matter, nor how many decimals you keep before rounding.
CREATE OR REPLACE SCRIPT CAPSTONE.SELF_CHECK() RETURNS TABLE AS
local SCHEMA = 'CAPSTONE'

-- Each view: the columns it must have (int: whole number, dec1: rounded to 1 decimal, text), the key column that
-- identifies a row, the number of rows, the fingerprint of the whole result and one per column (with the key).
local QUESTIONS = {
    {view = 'Q1_TOP_ZONES', rows = 5, key = 'PICKUP_RANK',
     columns = {{'PICKUP_RANK', 'int'}, {'ZONE_ID', 'int'}, {'ZONE_NAME', 'text'}, {'BOROUGH', 'text'},
                {'PICKUPS', 'int'}},
     all = '6b7717de15943900371c092b4d3a32304a7960b523c91ceee118e36aff2188f2',
     each = {
         PICKUP_RANK = 'd77cc5e0bc9ff1db4415210157909cca45633959e38432a4841d11d84001bfc8',
         ZONE_ID = 'dc4c87f3e188c68aae57a36969dfa04e555b0b224da5a0ba10f4651409960303',
         ZONE_NAME = 'e884d0258048274ff83e7b1777f4e053630e31893566e166111b72e99258b1be',
         BOROUGH = 'f258afcb7fb2a6f32dce364808b9f87a328f8fa13aa47dd7d654ab3886454416',
         PICKUPS = '6b9050739032981ae44c1215722bc41ad4e68da74f1d45ca20ddfd99a4843981'}},
    {view = 'Q2_CARD_TIPS', rows = 5, key = 'BOROUGH',
     columns = {{'BOROUGH', 'text'}, {'CARD_TRIPS', 'int'}, {'TIP_PCT', 'dec1'}},
     all = '8358a45cd2cd455c24a44de4a705921c6d39a311821a6dc4e2081646aaaade2b',
     each = {
         BOROUGH = '04148976d0ba2a597d02dfc07abfeb45719ec4505e9bc5136078359b1acf51df',
         CARD_TRIPS = 'ecf1d4d9c3ef91bb09cc9dd15619b68762f480561f57eebe6a2f44e06697e0bb',
         TIP_PCT = '57fb842304d34ede26f9a3680198a01bb4ae59f1b08c20672e412c017e295d16'}},
    {view = 'Q3_BEST_ZONES', rows = 4, key = 'BOROUGH',
     columns = {{'BOROUGH', 'text'}, {'ZONE_ID', 'int'}, {'ZONE_NAME', 'text'}, {'FORECAST_PICKUPS', 'int'}},
     all = '3c555d5a7bac9f85adfef55713d320d5ed2a29fad259649a2476454a7043103a',
     each = {
         BOROUGH = 'f1ce5df42651bb31a1c6f9d10a4f3c025f7b535560760002fafecb5fc08632b7',
         ZONE_ID = 'd3529e10cb09fba219a182f27465583fec3845f759299fd3e223f9f77f4a3732',
         ZONE_NAME = '3b8a58085bd9bd05804713e06dd54105fd7cba74c5c346d8267627ae50655572',
         FORECAST_PICKUPS = '91c74f916b0dafd6f4cb91c02eb625b7239454b343a0201227a8edc231e944be'}},
    {view = 'Q4_AIRPORT_SHARE', rows = 1, key = nil,
     columns = {{'TRIPS', 'int'}, {'AIRPORT_TRIPS', 'int'}, {'AIRPORT_SHARE_PCT', 'dec1'}},
     all = 'fcb7b6c2578fe5c6b13b3e400b692d02399632823dc0e4edd2b0bf6642c85828',
     each = {
         TRIPS = '413305cffb6af6aac180d4e9800d0228580991e47639542e1b20780a93272147',
         AIRPORT_TRIPS = '920c37d6464a8f20e8930c1980560dfd8ab7183334a20fa9447ecd5edb7a83b8',
         AIRPORT_SHARE_PCT = '8c92bebd740430af1b95f3b0deb80df3b03cc6f9d8417b1dffb75d5c37c707b5'}},
}

-- The text of one value. Numbers become exact decimals first (6 places, so a DOUBLE's 8.1499999999 is 8.15),
-- then they are rounded half up to whole numbers or to 1 decimal.
local function canonical(column, kind)
    local c = '"' .. column .. '"'
    local e
    if kind == 'int' then
        e = 'CAST(ROUND(CAST(' .. c .. ' AS DECIMAL(36,6)), 0) AS DECIMAL(18,0))'
    elseif kind == 'dec1' then
        e = 'CAST(ROUND(CAST(' .. c .. ' AS DECIMAL(36,6)), 1) AS DECIMAL(18,1))'
    end
    if e then
        e = 'CAST(' .. e .. ' AS VARCHAR(40))'
    else
        e = 'TRIM(' .. c .. ')'
    end
    return 'COALESCE(' .. e .. ", 'NULL')"
end

-- Number of rows and the fingerprint of the given columns: one line per row, the lines sorted and joined.
local function fingerprint(view, cols)
    local parts = {}
    for i = 1, #cols do
        parts[i] = canonical(cols[i][1], cols[i][2])
    end
    local ok, res = pquery('SELECT CAST(COUNT(*) AS DOUBLE) AS FP_ROWS, '
        .. "HASH_SHA256(GROUP_CONCAT(FP_ROW ORDER BY FP_ROW SEPARATOR ';')) AS FP_HASH "
        .. 'FROM (SELECT ' .. table.concat(parts, " || '|' || ") .. ' AS FP_ROW FROM '
        .. SCHEMA .. '.' .. view .. ')')
    if not ok then
        return nil, nil, res.error_message
    end
    return res[1].FP_ROWS, res[1].FP_HASH, nil
end

local function check(q)
    local name = SCHEMA .. '.' .. q.view
    local found = query([[SELECT CAST(COUNT(*) AS DOUBLE) AS N FROM EXA_ALL_VIEWS
                          WHERE VIEW_SCHEMA = :s AND VIEW_NAME = :v]], {s = SCHEMA, v = q.view})
    if found[1].N == 0 then
        local tables = query([[SELECT CAST(COUNT(*) AS DOUBLE) AS N FROM EXA_ALL_TABLES
                               WHERE TABLE_SCHEMA = :s AND TABLE_NAME = :v]], {s = SCHEMA, v = q.view})
        if tables[1].N > 0 then
            return 'view/column missing', name .. ' is a table - create it as a view'
        end
        return 'view/column missing', 'no view ' .. name
    end
    local ok, res = pquery('SELECT * FROM ' .. name .. ' WHERE 1 = 0')
    if not ok then
        return 'view fails', string.sub(res.error_message, 1, 250)
    end
    local have = {}
    local listed = query([[SELECT COLUMN_NAME FROM EXA_ALL_COLUMNS WHERE COLUMN_SCHEMA = :s AND COLUMN_TABLE = :v]],
                         {s = SCHEMA, v = q.view})
    for i = 1, #listed do
        have[listed[i].COLUMN_NAME] = true
    end
    local missing = {}
    for i = 1, #q.columns do
        if not have[q.columns[i][1]] then
            missing[#missing + 1] = q.columns[i][1]
        end
    end
    if #missing > 0 then
        return 'view/column missing', 'missing column(s): ' .. table.concat(missing, ', ')
    end
    local rows, hash, err = fingerprint(q.view, q.columns)
    if err then
        return 'view fails', string.sub(err, 1, 250)
    end
    if hash == q.all then
        return 'OK', 'all values match'
    end
    if rows ~= q.rows then
        return 'wrong values', string.format('%d rows - expected %d', rows, q.rows)
    end
    local kinds, differ = {}, {}
    for i = 1, #q.columns do
        kinds[q.columns[i][1]] = q.columns[i][2]
    end
    for i = 1, #q.columns do
        local col = q.columns[i][1]
        local cols = {{col, kinds[col]}}
        if q.key and col ~= q.key then
            cols = {{q.key, kinds[q.key]}, {col, kinds[col]}}
        end
        local _, h = fingerprint(q.view, cols)
        if h ~= q.each[col] then
            differ[#differ + 1] = col
        end
    end
    if #differ == 0 then
        return 'wrong values', 'right number of rows - check the values'
    end
    return 'wrong values', 'right number of rows - check ' .. table.concat(differ, ', ')
end

local out = {}
for i = 1, #QUESTIONS do
    local status, hint = check(QUESTIONS[i])
    out[#out + 1] = {QUESTIONS[i].view, status, hint}
end
exit(out, 'QUESTION VARCHAR(20), STATUS VARCHAR(20), HINT VARCHAR(300)')
/
